import { Directive, ElementRef, inject, Input, Renderer2, AfterViewInit, OnDestroy, NgZone } from '@angular/core';
import { TranslateService } from '@ngx-translate/core'; // Подключаем сервис переводов
import { Subscription } from 'rxjs';
import SplitType from 'split-type';

export type TextAnimationType = 'left' | 'right' | 'up' | 'down' | 'rotate' | 'scale' | 'fade';

@Directive({
    selector: '[appTextAnimation]',
    standalone: true
})
export class TextAnimationDirective implements AfterViewInit, OnDestroy {
    private readonly elementRef = inject(ElementRef<HTMLElement>);
    private readonly renderer = inject(Renderer2);
    private readonly ngZone = inject(NgZone);
    private readonly translateService = inject(TranslateService); // Внедряем сервис
    private isFirstLoad = true;
    private intersectionObserver?: IntersectionObserver;
    private langChangeSub?: Subscription;
    private splitType?: SplitType;
    private activeAnimations: Animation[] = [];
    private isVisible = false;

    @Input('appTextAnimation') animation: TextAnimationType = 'fade';
    @Input() translationKey = ''; // Новый инпут для ключа перевода
    @Input() delay = 0;
    @Input() stagger = 20;
    @Input() duration = 1200;

    ngAfterViewInit(): void {
        const element = this.elementRef.nativeElement;

        if (this.animation === 'rotate') {
            this.renderer.setStyle(element, 'perspective', '400px');
        }

        // 1. Отслеживаем появление во вьюпорте
        this.intersectionObserver = new IntersectionObserver(
            (entries: IntersectionObserverEntry[]) => {
                // Проверяем первый элемент массива на пересечение экрана
                if (!entries[0]?.isIntersecting) return;

                this.isVisible = true;

                // Загружаем первый перевод и анимируем
                this.loadAndAnimate();
                this.intersectionObserver?.disconnect();
            },
            { threshold: 0.15 }
        );
        this.intersectionObserver.observe(element);

        // 2. Подписываемся на системное изменение языка в приложении
        this.langChangeSub = this.translateService.onLangChange.subscribe(() => {
            if (this.isVisible) {
                this.ngZone.runOutsideAngular(() => {
                    this.loadAndAnimate();
                });
            }
        });
    }

    private loadAndAnimate(): void {
        if (!this.translationKey) return;

        this.translateService.get(this.translationKey).subscribe((translatedText: string) => {
            const element = this.elementRef.nativeElement;

            // Очищаем старые анимации и DOM структуру SplitType
            this.cleanupAnimations();
            this.splitType?.revert();

            // Вставляем чистый новый текст
            this.renderer.setProperty(element, 'textContent', translatedText);

            if (!translatedText.trim()) return;

            // Пересобираем SplitType для нового языка
            this.splitType = new SplitType(element, { types: ['words', 'chars'] });
            const chars = this.splitType.chars as HTMLElement[];

            // Сценарий 1: ПЕРВЫЙ ВХОД НА ЭКРАН (Красивая посимвольная анимация)
            if (this.isFirstLoad) {
                this.isFirstLoad = false; // Сбрасываем флаг

                chars.forEach(char => {
                    this.renderer.setStyle(char, 'display', 'inline-block');
                    this.renderer.setStyle(char, 'opacity', '0');
                    this.renderer.setStyle(char, 'will-change', 'transform, opacity');
                });

                const keyframes = this.getKeyframes();
                chars.forEach((char, index) => {
                    const calculatedDelay = this.delay + (index * this.stagger);
                    const anim = char.animate(keyframes, {
                        duration: this.duration,
                        delay: calculatedDelay,
                        fill: 'forwards',
                        easing: 'cubic-bezier(0.16, 1, 0.3, 1)'
                    });
                    this.activeAnimations.push(anim);
                });
            }
            // Сценарий 2: ПОСЛЕДУЮЩАЯ СМЕНА ЯЗЫКА (Мгновенное или быстрое отображение)
            else {
                chars.forEach(char => {
                    this.renderer.setStyle(char, 'display', 'inline-block');
                    // Вместо анимации вылета просто делаем буквы сразу видимыми в их финальной позиции
                    this.renderer.setStyle(char, 'opacity', '1');
                    this.renderer.setStyle(char, 'transform', 'none');
                });

                // Опционально: можно добавить микро-анимацию плавного проявления (fade-in) 
                // для всего блока целиком, чтобы смена букв не была слишком топорной:
                element.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 200, easing: 'ease-out' });
            }
        });
    }

    private cleanupAnimations(): void {
        this.activeAnimations.forEach(anim => anim.cancel());
        this.activeAnimations = [];
    }

    private getKeyframes(): Keyframe[] {
        switch (this.animation) {
            case 'left': return [{ transform: 'translateX(-20px)', opacity: 0 }, { transform: 'translateX(0)', opacity: 1 }];
            case 'right': return [{ transform: 'translateX(20px)', opacity: 0 }, { transform: 'translateX(0)', opacity: 1 }];
            case 'up': return [{ transform: 'translateY(80px)', opacity: 0 }, { transform: 'translateY(0)', opacity: 1 }];
            case 'down': return [{ transform: 'translateY(-20px)', opacity: 0 }, { transform: 'translateY(0)', opacity: 1 }];
            case 'rotate': return [{ transform: 'rotateX(50deg)', opacity: 0 }, { transform: 'rotateX(0deg)', opacity: 1 }];
            case 'scale': return [{ transform: 'scale(0.7)', opacity: 0 }, { transform: 'scale(1)', opacity: 1 }];
            case 'fade':
            default: return [{ opacity: 0 }, { opacity: 1 }];
        }
    }

    ngOnDestroy(): void {
        this.intersectionObserver?.disconnect();
        this.langChangeSub?.unsubscribe(); // Важно отписаться, чтобы не было утечек памяти
        this.cleanupAnimations();
        this.splitType?.revert();
    }
}
