import {
    AfterViewInit,
    Directive,
    ElementRef,
    Input,
    OnDestroy,
    inject
} from '@angular/core';

import { animate } from 'animejs';

import { TextAnimationType } from './text-animation.type';

@Directive({
    selector: '[appTextAnimation]',
    standalone: true
})
export class TextAnimationDirective implements AfterViewInit, OnDestroy {

    private readonly elementRef = inject(ElementRef<HTMLElement>);

    private observer?: IntersectionObserver;

    @Input('appTextAnimation')
    animation: TextAnimationType = 'fade';

    @Input()
    delay = 0;

    @Input()
    duration = 1200;

    @Input()
    distance = 40;

    ngAfterViewInit(): void {

        const element = this.elementRef.nativeElement;

        element.style.opacity = '0';

        this.observer = new IntersectionObserver(
            entries => {

                if (!entries[0]?.isIntersecting) {
                    return;
                }

                animate(element, {
                    ...this.getAnimationConfig(),
                    opacity: [0, 1],
                    duration: this.duration,
                    delay: this.delay,
                    ease: 'outExpo'
                });

                this.observer?.disconnect();
            },
            {
                threshold: 0.15
            }
        );

        this.observer.observe(element);
    }

    private getAnimationConfig() {

        switch (this.animation) {

            case 'left':
                return {
                    translateX: [-this.distance, 0]
                };

            case 'right':
                return {
                    translateX: [this.distance, 0]
                };

            case 'up':
                return {
                    translateY: [this.distance, 0]
                };

            case 'down':
                return {
                    translateY: [-this.distance, 0]
                };

            case 'scale':
                return {
                    scale: [0.8, 1]
                };

            case 'rotate':
                return {
                    rotateX: ['50deg', '0deg']
                };

            case 'fade':
            default:
                return {};
        }
    }

    ngOnDestroy(): void {
        this.observer?.disconnect();
    }
}